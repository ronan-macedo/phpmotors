<?php
$page_title = "500";
require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/header.php';
?>
<main>
    <div class="content-container">
        <h1>Server Error</h1>
        <p>Sorry our server seems to be experiencing some technical difficulties</p>
    </div>
</main>
<?php
require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/footer.php';
?>
