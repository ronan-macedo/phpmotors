<?php
$page_title = "Template";
require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/header.php';
?>
<main>
    <div class="content-container">
        <h1>Content Title Here</h1>
    </div>
</main>
<?php
require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/footer.php';
?>
